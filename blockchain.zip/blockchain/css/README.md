It contains all the required stylesheets.
